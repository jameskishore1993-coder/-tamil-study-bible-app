import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TamilStudyBibleApp());
}

// -------------------------------------------------------------
// Database Helper
// -------------------------------------------------------------
class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('tamil_study_bible.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    bool exists = await databaseExists(path);
    if (!exists) {
      try {
        await Directory(dirname(path)).create(recursive: true);
        ByteData data = await rootBundle.load('assets/$filePath');
        List<int> bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
        await File(path).writeAsBytes(bytes, flush: true);
      } catch (e) {
        return await openDatabase(path, version: 1);
      }
    }
    return await openDatabase(path);
  }

  Future<List<Map<String, dynamic>>> getBooks() async {
    final db = await instance.database;
    return await db.query('books', orderBy: 'id ASC');
  }

  Future<Map<String, dynamic>?> getBookDetails(int bookId) async {
    final db = await instance.database;
    final res = await db.query('books', where: 'id = ?', whereArgs: [bookId]);
    return res.isNotEmpty ? res.first : null;
  }

  Future<Map<String, dynamic>?> getChapterContext(int bookId, int chapter) async {
    final db = await instance.database;
    final res = await db.query(
      'chapter_contexts',
      where: 'book_id = ? AND chapter = ?',
      whereArgs: [bookId, chapter],
    );
    return res.isNotEmpty ? res.first : null;
  }

  Future<List<Map<String, dynamic>>> getVerses(int bookId, int chapter) async {
    final db = await instance.database;
    return await db.query(
      'verses',
      where: 'book_id = ? AND chapter = ?',
      whereArgs: [bookId, chapter],
      orderBy: 'verse ASC',
    );
  }

  Future<List<Map<String, dynamic>>> getVerseLexicon(int bookId, int chapter, int verse) async {
    final db = await instance.database;
    return await db.query(
      'verse_lexicon',
      where: 'book_id = ? AND chapter = ? AND verse = ?',
      whereArgs: [bookId, chapter, verse],
    );
  }

  Future<List<Map<String, dynamic>>> getCrossReferences(int bookId, int chapter, int verse) async {
    final db = await instance.database;
    return await db.rawQuery('''
      SELECT cr.to_chapter, cr.to_verse, b.name_ta as to_book_name, v.text as verse_text
      FROM cross_references cr
      JOIN books b ON cr.to_book_id = b.id
      LEFT JOIN verses v ON cr.to_book_id = v.book_id AND cr.to_chapter = v.chapter AND cr.to_verse = v.verse
      WHERE cr.from_book_id = ? AND cr.from_chapter = ? AND cr.from_verse = ?
    ''', [bookId, chapter, verse]);
  }

  Future<List<Map<String, dynamic>>> searchVerses(String keyword) async {
    final db = await instance.database;
    return await db.rawQuery('''
      SELECT v.chapter, v.verse, v.text, b.name_ta as book_name
      FROM verses v
      JOIN books b ON v.book_id = b.id
      WHERE v.text LIKE ?
      LIMIT 100
    ''', ['%$keyword%']);
  }

  Future<List<Map<String, dynamic>>> searchDictionary(String keyword) async {
    final db = await instance.database;
    return await db.query(
      'dictionary',
      where: 'word_ta LIKE ? OR transliteration LIKE ?',
      whereArgs: ['%$keyword%', '%$keyword%'],
      orderBy: 'word_ta ASC',
    );
  }

  Future<int> addNote(int bookId, int chapter, int verse, String note) async {
    final db = await instance.database;
    return await db.insert('study_notes', {
      'book_id': bookId,
      'chapter': chapter,
      'verse': verse,
      'note': note,
    });
  }

  Future<List<Map<String, dynamic>>> getNotes(int bookId, int chapter, int verse) async {
    final db = await instance.database;
    return await db.query(
      'study_notes',
      where: 'book_id = ? AND chapter = ? AND verse = ?',
      whereArgs: [bookId, chapter, verse],
    );
  }
}

// -------------------------------------------------------------
// App Entry & Home
// -------------------------------------------------------------
class TamilStudyBibleApp extends StatelessWidget {
  const TamilStudyBibleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'தமிழ் வரலாற்று ஆராய்ச்சி வேதாகமம்',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF1E3A8A),
        scaffoldBackgroundColor: const Color(0xFFF8FAFC),
        appBarTheme: const AppBarTheme(
          elevation: 1,
          backgroundColor: Color(0xFF1E3A8A),
          foregroundColor: Colors.white,
        ),
      ),
      home: const MainBibleScreen(),
    );
  }
}

class MainBibleScreen extends StatefulWidget {
  const MainBibleScreen({super.key});

  @override
  State<MainBibleScreen> createState() => _MainBibleScreenState();
}

class _MainBibleScreenState extends State<MainBibleScreen> {
  int currentBookId = 1;
  String currentBookName = 'ஆதியாகமம்';
  int currentChapter = 1;
  int maxChapters = 50;
  double fontSize = 18.0;

  Map<String, dynamic>? currentBookInfo;
  Map<String, dynamic>? currentChapterInfo;
  List<Map<String, dynamic>> verses = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadAllData();
  }

  Future<void> loadAllData() async {
    setState(() => isLoading = true);
    final bInfo = await DatabaseHelper.instance.getBookDetails(currentBookId);
    final chInfo = await DatabaseHelper.instance.getChapterContext(currentBookId, currentChapter);
    final vList = await DatabaseHelper.instance.getVerses(currentBookId, currentChapter);
    setState(() {
      currentBookInfo = bInfo;
      currentChapterInfo = chInfo;
      verses = vList;
      isLoading = false;
    });
  }

  void _showBookHistoryDialog() {
    if (currentBookInfo == null) return;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('${currentBookInfo!['name_ta']} - வரலாற்று அறிமுகம்', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1E3A8A))),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _infoTile('எழுதியவர்:', currentBookInfo!['author_ta']),
              _infoTile('காலம்:', currentBookInfo!['written_period']),
              _infoTile('வாசகர்கள்:', currentBookInfo!['audience']),
              _infoTile('மையக்கருத்து:', currentBookInfo!['main_theme']),
              const Divider(height: 20),
              const Text('வரலாற்றுப் பின்னணி:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 6),
              Text(
                currentBookInfo!['historical_background'],
                style: const TextStyle(fontSize: 14, height: 1.5, color: Colors.black87),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('மூடுக')),
        ],
      ),
    );
  }

  Widget _infoTile(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(color: Colors.black87, fontSize: 13.5),
          children: [
            TextSpan(text: '$label ', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1E3A8A))),
            TextSpan(text: value),
          ],
        ),
      ),
    );
  }

  void _selectBookAndChapter() async {
    final books = await DatabaseHelper.instance.getBooks();
    if (!mounted) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.85,
        maxChildSize: 0.95,
        builder: (_, scrollController) {
          return DefaultTabController(
            length: 2,
            child: Scaffold(
              appBar: AppBar(
                title: const Text('புத்தகம் & அதிகாரம் தேர்வு'),
                bottom: const TabBar(
                  indicatorColor: Colors.amber,
                  labelColor: Colors.white,
                  tabs: [
                    Tab(text: 'பழைய ஏற்பாடு (39)'),
                    Tab(text: 'புதிய ஏற்பாடு (27)'),
                  ],
                ),
              ),
              body: TabBarView(
                children: [
                  _buildBookList(books.where((b) => b['testament'] == 'OT').toList()),
                  _buildBookList(books.where((b) => b['testament'] == 'NT').toList()),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildBookList(List<Map<String, dynamic>> bookSubList) {
    return ListView.separated(
      itemCount: bookSubList.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (ctx, i) {
        final b = bookSubList[i];
        return ListTile(
          title: Text(b['name_ta'], style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('${b['author_ta']} • ${b['written_period']}'),
          trailing: Chip(label: Text('${b['total_chapters']} அதி.')),
          onTap: () {
            Navigator.pop(ctx);
            _pickChapterDialog(b['id'], b['name_ta'], b['total_chapters']);
          },
        );
      },
    );
  }

  void _pickChapterDialog(int bookId, String bookName, int chaptersCount) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('$bookName - அதிகாரத்தைத் தேர்ந்தெடுக்கவும்'),
        content: SizedBox(
          width: double.maxFinite,
          child: GridView.builder(
            shrinkWrap: true,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 5,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
            ),
            itemCount: chaptersCount,
            itemBuilder: (_, index) {
              int ch = index + 1;
              return ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.zero,
                  backgroundColor: ch == currentChapter && bookId == currentBookId
                      ? const Color(0xFF1E3A8A)
                      : Colors.grey.shade200,
                  foregroundColor: ch == currentChapter && bookId == currentBookId
                      ? Colors.white
                      : Colors.black87,
                ),
                onPressed: () {
                  setState(() {
                    currentBookId = bookId;
                    currentBookName = bookName;
                    currentChapter = ch;
                    maxChapters = chaptersCount;
                  });
                  Navigator.pop(ctx);
                  loadAllData();
                },
                child: Text('$ch', style: const TextStyle(fontWeight: FontWeight.bold)),
              );
            },
          ),
        ),
      ),
    );
  }

  // 4 Tabs Study Panel: 1) வரலாறு 2) மூல அர்த்தம் 3) ஒப்புநோக்கு 4) குறிப்புகள்
  void _openStudyPanel(Map<String, dynamic> v) async {
    final int verseNum = v['verse'];
    final lexiconList = await DatabaseHelper.instance.getVerseLexicon(currentBookId, currentChapter, verseNum);
    final crossRefs = await DatabaseHelper.instance.getCrossReferences(currentBookId, currentChapter, verseNum);
    final notes = await DatabaseHelper.instance.getNotes(currentBookId, currentChapter, verseNum);

    if (!mounted) return;

    final noteInputController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setSheetState) {
          return Padding(
            padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
            child: Container(
              height: MediaQuery.of(context).size.height * 0.78,
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '$currentBookName $currentChapter:$verseNum',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF1E3A8A)),
                      ),
                      IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(ctx)),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEEF2F6),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      v['text'],
                      style: const TextStyle(fontSize: 15, fontStyle: FontStyle.italic, color: Colors.black87),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Expanded(
                    child: DefaultTabController(
                      length: 4,
                      child: Column(
                        children: [
                          Container(
                            color: Colors.white,
                            child: const TabBar(
                              isScrollable: true,
                              labelColor: Color(0xFF1E3A8A),
                              indicatorColor: Color(0xFF1E3A8A),
                              tabs: [
                                Tab(icon: Icon(Icons.history_edu), text: 'வரலாற்றுப் பின்னணி'),
                                Tab(icon: Icon(Icons.translate), text: 'மூல அர்த்தம்'),
                                Tab(icon: Icon(Icons.compare_arrows), text: 'ஒப்புநோக்கு'),
                                Tab(icon: Icon(Icons.edit_note), text: 'குறிப்புகள்'),
                              ],
                            ),
                          ),
                          Expanded(
                            child: TabBarView(
                              children: [
                                // Tab 1: வசன & அதிகார வரலாற்றுப் பின்னணி
                                ListView(
                                  padding: const EdgeInsets.all(12),
                                  children: [
                                    if (v['historical_note'] != null && v['historical_note'].toString().isNotEmpty) ...[
                                      Card(
                                        color: const Color(0xFFF0FDF4),
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                        child: Padding(
                                          padding: const EdgeInsets.all(12),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              const Text('வசன வரலாற்றுப் பின்னணி:', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF166534))),
                                              const SizedBox(height: 6),
                                              Text(v['historical_note'], style: const TextStyle(fontSize: 14, height: 1.45)),
                                            ],
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 12),
                                    ],
                                    if (currentChapterInfo != null) ...[
                                      Card(
                                        elevation: 0.5,
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                        child: Padding(
                                          padding: const EdgeInsets.all(12),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              const Text('காலமும் வரலாற்றுச் சூழலும்:', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1E3A8A))),
                                              const SizedBox(height: 4),
                                              Text(currentChapterInfo!['setting_and_timeline'], style: const TextStyle(fontSize: 13.5)),
                                              const Divider(height: 16),
                                              const Text('கலாச்சாரப் பின்னணி:', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1E3A8A))),
                                              const SizedBox(height: 4),
                                              Text(currentChapterInfo!['cultural_context'], style: const TextStyle(fontSize: 13.5)),
                                              const Divider(height: 16),
                                              const Text('இறையியல் நோக்கம்:', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1E3A8A))),
                                              const SizedBox(height: 4),
                                              Text(currentChapterInfo!['theological_significance'], style: const TextStyle(fontSize: 13.5)),
                                            ],
                                          ),
                                        ),
                                      )
                                    ] else
                                      const Center(child: Padding(
                                        padding: EdgeInsets.all(20),
                                        child: Text('இவ்வதிகாரத்திற்கான வரலாற்றுத் தகவல் தொகுக்கப்படுகிறது...'),
                                      )),
                                  ],
                                ),

                                // Tab 2: மூல மொழி ஆய்வு (Lexicon)
                                lexiconList.isEmpty
                                    ? const Center(child: Text('மூல மொழித் தகவல்கள் சேர்க்கப்படுகின்றன.'))
                                    : ListView.separated(
                                        padding: const EdgeInsets.only(top: 8),
                                        itemCount: lexiconList.length,
                                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                                        itemBuilder: (_, idx) {
                                          final item = lexiconList[idx];
                                          return Card(
                                            elevation: 0.8,
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(10),
                                              side: BorderSide(color: Colors.grey.shade300),
                                            ),
                                            child: Padding(
                                              padding: const EdgeInsets.all(12),
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      Text(
                                                        item['tamil_word'],
                                                        style: const TextStyle(
                                                          fontSize: 17,
                                                          fontWeight: FontWeight.bold,
                                                          color: Color(0xFF1E3A8A),
                                                        ),
                                                      ),
                                                      Container(
                                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                                        decoration: BoxDecoration(
                                                          color: const Color(0xFFDBEAFE),
                                                          borderRadius: BorderRadius.circular(12),
                                                        ),
                                                        child: Text(
                                                          '${item['strongs_number']} (${item['language']})',
                                                          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF1E40AF)),
                                                        ),
                                                      )
                                                    ],
                                                  ),
                                                  const SizedBox(height: 6),
                                                  Row(
                                                    children: [
                                                      Text(
                                                        item['original_script'],
                                                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal),
                                                      ),
                                                      const SizedBox(width: 8),
                                                      Text(
                                                        '(${item['transliteration']})',
                                                        style: TextStyle(fontSize: 14, color: Colors.grey.shade700, fontStyle: FontStyle.italic),
                                                      ),
                                                    ],
                                                  ),
                                                  const SizedBox(height: 6),
                                                  Text('நேரடி பொருள்: ${item['literal_meaning']}', style: const TextStyle(fontWeight: FontWeight.w600)),
                                                  const SizedBox(height: 4),
                                                  Text('வேத ஆழம்: ${item['theological_root']}', style: const TextStyle(fontSize: 13.5, color: Colors.black87, height: 1.35)),
                                                  const SizedBox(height: 4),
                                                  Text('வரலாற்றுப் பிரயோகம்: ${item['historical_cultural_usage']}', style: const TextStyle(fontSize: 13, color: Colors.indigo, fontStyle: FontStyle.italic)),
                                                ],
                                              ),
                                            ),
                                          );
                                        },
                                      ),

                                // Tab 3: ஒப்புநோக்கு வசனங்கள்
                                crossRefs.isEmpty
                                    ? const Center(child: Text('ஒப்புநோக்கு வசனங்கள் இல்லை.'))
                                    : ListView.builder(
                                        padding: const EdgeInsets.only(top: 8),
                                        itemCount: crossRefs.length,
                                        itemBuilder: (_, idx) {
                                          final cr = crossRefs[idx];
                                          return Card(
                                            margin: const EdgeInsets.symmetric(vertical: 4),
                                            child: ListTile(
                                              leading: const Icon(Icons.bookmark_border, color: Color(0xFF1E3A8A)),
                                              title: Text(
                                                '${cr['to_book_name']} ${cr['to_chapter']}:${cr['to_verse']}',
                                                style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1E3A8A)),
                                              ),
                                              subtitle: Text(cr['verse_text'] ?? 'வசன உரை இணைக்கப்பட்டுள்ளது'),
                                            ),
                                          );
                                        },
                                      ),

                                // Tab 4: சொந்த குறிப்புகள்
                                ListView(
                                  padding: const EdgeInsets.only(top: 8),
                                  children: [
                                    TextField(
                                      controller: noteInputController,
                                      maxLines: 3,
                                      decoration: InputDecoration(
                                        hintText: 'இவ்வசனத்திற்கான தியானக் குறிப்பை எழுதுக...',
                                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: ElevatedButton.icon(
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: const Color(0xFF1E3A8A),
                                          foregroundColor: Colors.white,
                                        ),
                                        onPressed: () async {
                                          if (noteInputController.text.trim().isNotEmpty) {
                                            await DatabaseHelper.instance.addNote(
                                              currentBookId,
                                              currentChapter,
                                              verseNum,
                                              noteInputController.text.trim(),
                                            );
                                            noteInputController.clear();
                                            Navigator.pop(ctx);
                                            ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(content: Text('குறிப்பு சேமிக்கப்பட்டது!')),
                                            );
                                          }
                                        },
                                        icon: const Icon(Icons.save, size: 18),
                                        label: const Text('சேமி'),
                                      ),
                                    ),
                                    const Divider(),
                                    if (notes.isNotEmpty) ...[
                                      const Text('சேமிக்கப்பட்ட குறிப்புகள்:', style: TextStyle(fontWeight: FontWeight.bold)),
                                      ...notes.map((n) => ListTile(
                                            contentPadding: EdgeInsets.zero,
                                            leading: const Icon(Icons.arrow_right),
                                            title: Text(n['note']),
                                          )),
                                    ]
                                  ],
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: InkWell(
          onTap: _selectBookAndChapter,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('$currentBookName $currentChapter', style: const TextStyle(fontWeight: FontWeight.bold)),
              const Icon(Icons.arrow_drop_down, color: Colors.white),
            ],
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            tooltip: 'புத்தகத்தின் வரலாற்றுப் பின்னணி',
            onPressed: _showBookHistoryDialog,
          ),
          IconButton(
            icon: const Icon(Icons.search),
            tooltip: 'வேத வார்த்தை தேடல்',
            onPressed: () => showSearch(context: context, delegate: BibleSearchDelegate()),
          ),
          IconButton(
            icon: const Icon(Icons.menu_book),
            tooltip: 'வேதாகம அகராதி',
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const DictionaryScreen()));
            },
          ),
          PopupMenuButton<double>(
            icon: const Icon(Icons.format_size),
            tooltip: 'எழுத்துரு அளவு',
            onSelected: (size) => setState(() => fontSize = size),
            itemBuilder: (_) => [
              const PopupMenuItem(value: 15.0, child: Text('சிறியது (15px)')),
              const PopupMenuItem(value: 18.0, child: Text('நடுத்தரம் (18px)')),
              const PopupMenuItem(value: 22.0, child: Text('பெரியது (22px)')),
              const PopupMenuItem(value: 26.0, child: Text('மிகப் பெரியது (26px)')),
            ],
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Chapter Cultural Banner
                if (currentChapterInfo != null)
                  Container(
                    width: double.infinity,
                    color: const Color(0xFFEFF6FF),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        const Icon(Icons.history_edu, size: 20, color: Color(0xFF1E3A8A)),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            currentChapterInfo!['setting_and_timeline'],
                            style: const TextStyle(fontSize: 12.5, color: Color(0xFF1E3A8A), fontWeight: FontWeight.w600),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                Expanded(
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    itemCount: verses.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, index) {
                      final item = verses[index];
                      return InkWell(
                        borderRadius: BorderRadius.circular(8),
                        onTap: () => _openStudyPanel(item),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          child: RichText(
                            text: TextSpan(
                              style: TextStyle(fontSize: fontSize, color: const Color(0xFF222222), height: 1.6),
                              children: [
                                TextSpan(
                                  text: '${item['verse']}  ',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: const Color(0xFF1E3A8A),
                                    fontSize: fontSize * 0.9,
                                  ),
                                ),
                                TextSpan(text: item['text']),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
      bottomNavigationBar: Container(
        height: 52,
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 4, offset: const Offset(0, -2))],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            TextButton.icon(
              onPressed: currentChapter > 1
                  ? () {
                      setState(() => currentChapter--);
                      loadAllData();
                    }
                  : null,
              icon: const Icon(Icons.chevron_left),
              label: const Text('முந்தைய அதிகாரம்'),
            ),
            Text('$currentChapter / $maxChapters', style: const TextStyle(fontWeight: FontWeight.bold)),
            TextButton.icon(
              onPressed: currentChapter < maxChapters
                  ? () {
                      setState(() => currentChapter++);
                      loadAllData();
                    }
                  : null,
              icon: const Icon(Icons.chevron_right),
              label: const Text('அடுத்த அதிகாரம்'),
            ),
          ],
        ),
      ),
    );
  }
}

// -------------------------------------------------------------
// Bible Dictionary Screen
// -------------------------------------------------------------
class DictionaryScreen extends StatefulWidget {
  const DictionaryScreen({super.key});

  @override
  State<DictionaryScreen> createState() => _DictionaryScreenState();
}

class _DictionaryScreenState extends State<DictionaryScreen> {
  List<Map<String, dynamic>> items = [];

  @override
  void initState() {
    super.initState();
    _search('');
  }

  void _search(String text) async {
    final res = await DatabaseHelper.instance.searchDictionary(text.trim());
    setState(() => items = res);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('வேதாகம ஆராய்ச்சி அகராதி')),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            color: Colors.white,
            child: TextField(
              decoration: InputDecoration(
                hintText: 'அகராதி சொல்லைத் தேடுக (எ.கா: கிருபை, வார்த்தை)...',
                prefixIcon: const Icon(Icons.search),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onChanged: _search,
            ),
          ),
          Expanded(
            child: items.isEmpty
                ? const Center(child: Text('சொற்கள் எதுவும் கிடைக்கவில்லை.'))
                : ListView.separated(
                    padding: const EdgeInsets.all(12),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (ctx, i) {
                      final d = items[i];
                      return Card(
                        elevation: 1,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    d['word_ta'],
                                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Color(0xFF1E3A8A)),
                                  ),
                                  Chip(
                                    label: Text(d['category'] ?? 'பொதுவானது', style: const TextStyle(fontSize: 11)),
                                    padding: EdgeInsets.zero,
                                    visualDensity: VisualDensity.compact,
                                  ),
                                ],
                              ),
                              if (d['original_word'] != null && d['original_word'].toString().isNotEmpty)
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 6),
                                  child: Text(
                                    'மூலச்சொல்: ${d['original_word']} (${d['transliteration'] ?? ''})',
                                    style: const TextStyle(fontSize: 13, color: Colors.indigo, fontStyle: FontStyle.italic),
                                  ),
                                ),
                              Text(
                                d['definition'],
                                style: const TextStyle(fontSize: 14.5, height: 1.45, color: Colors.black87),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

// -------------------------------------------------------------
// Bible Word Search Delegate
// -------------------------------------------------------------
class BibleSearchDelegate extends SearchDelegate {
  @override
  String get searchFieldLabel => 'வார்த்தையைத் தேடுக (எ.கா: அன்பு, வெளிச்சம்)...';

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      if (query.isNotEmpty)
        IconButton(icon: const Icon(Icons.clear), onPressed: () => query = ''),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => close(context, null));
  }

  @override
  Widget buildResults(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: DatabaseHelper.instance.searchVerses(query.trim()),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final list = snapshot.data!;
        if (list.isEmpty) {
          return const Center(child: Text('பொருத்தமான வசனங்கள் கிடைக்கவில்லை.'));
        }
        return ListView.separated(
          itemCount: list.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (_, i) {
            final row = list[i];
            return ListTile(
              title: Text('${row['book_name']} ${row['chapter']}:${row['verse']}', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1E3A8A))),
              subtitle: Text(row['text']),
            );
          },
        );
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return const Center(child: Text('தேட விரும்பும் தமிழ் சொல்லை உள்ளிடவும்.'));
  }
}
